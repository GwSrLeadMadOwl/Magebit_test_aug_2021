const form = document.querySelector("#form");
const emailInput = document.querySelector("#email-input");
const postButton = document.querySelector("#post-button");
const checkTos = document.querySelector("#check-tos");
const message = document.querySelector("message");

window.addEventListener("load", () => {

    // if (postButton != null || postButton != undefined) {
    //     postButton.addEventListener("click", (e) => {
    //         e.preventDefault();
    //         validateForm();
    //     });
    // }

    // /^[^ ]+@+[a-z]{3,7}\.[a-z]{2,3}/
    // /^[^ ]+@[^ ]+\.[a-z]{2,3}$/

    // const validateEmail = (email) => {
    //     var reg = /^([\w-\.]+@(?!gmail.com)(?!yahoo.com)(?!outlook.com)([\w-]+\.)+[\w-]{2,4})?$/;
    //     // if (reg.test(email)) {
    //     if (reg.match(email)) {
    //         return true;
    //     }
    //     else {
    //         return false;
    //     }
    // };





    // “Please provide a valid e-mail address”
    // “You must accept the terms and conditions”
    // “Email address is required”
    // “We are not accepting subscriptions from Colombia emails”.

});

const validateForm = () => {
    // e.preventDefault();
    if (emailInput.value != null ||
        emailInput.value != undefined ||
        emailInput.value != "") {
        message.innerHTML = "Email address is required";
        console.log("Email address is required");
    };
};

